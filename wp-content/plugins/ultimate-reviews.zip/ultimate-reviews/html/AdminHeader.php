<div class="wrap">
<div class="Header"><h2><?php _e("Ultimate Reviews", 'ultimate-reviews') ?></h2></div>

<?php EWD_URP_Add_Header_Bar("Yes"); ?>
