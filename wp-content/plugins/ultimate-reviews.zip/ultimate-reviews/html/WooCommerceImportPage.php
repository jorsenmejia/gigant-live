<p>Import reviews from WooCommerce using the button below.</p>
<a href='edit.php?page=EWD-URP-Options&DisplayPage=WooCommerceImport&Action=EWD_URP_WooCommerceImport'>
<button class="button button-primary">Import</button>
</a>