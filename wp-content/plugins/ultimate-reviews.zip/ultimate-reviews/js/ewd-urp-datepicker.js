jQuery(document).ready(function($){
    jQuery('.ewd-urp-jquery-datepicker').datepicker({
        dateFormat : "yy-mm-dd",
    });
});
